import React from 'react'
import DetailProd from '../components/detailProd/DetailProd'

const DetailGame = () => {
  return (
    <DetailProd />
  )
}

export default DetailGame;
