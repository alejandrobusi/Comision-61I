import React from 'react'
import ProductsGalery from '../components/productsGalery/ProductsGalery'

const HomePage = () => {
  return (
    <ProductsGalery />
  )
}

export default HomePage
