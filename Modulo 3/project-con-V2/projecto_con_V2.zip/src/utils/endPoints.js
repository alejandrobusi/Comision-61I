export const endPoints = {
  user: "http://localhost:3000/users",
  products: "http://localhost:3000/products",
};
